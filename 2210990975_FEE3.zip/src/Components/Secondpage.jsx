import React from "react";

const Second =() =>{
    return(
        <>
<div className="group-2" id="a">
    <div className="text">
      <p className="title-2">LET´S go</p>
      <p className="body-text-2">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus lacinia
        odio vitae vestibulum vestibulum.
      </p>
    </div>
    <div className="row-3-group">
      <div className="col-10">
        <div className="content-1">
          <img
            className="place-your-design-here-double-click-to-edit"
            src="images/place_your_design_here_do_2.jpg"
            alt=""
            width={339}
            height={301}
          />
          <div className="col">
            <p className="title-3">Lorem ipsum</p>
            <p className="body-text-3">
              Lorem ipsum dolor sit amet,
              <br />
              consectetur &nbsp;adipisicing...
            </p>
          </div>
        </div>
        <img
          className="shadow"
          src="images/shadow_3.png"
          alt=""
          width={512}
          height={400}
        />
      </div>
      <div className="col-11">
        <div className="content-2">
          <img
            className="place-your-image-here-double-click-to-edit"
            src="images/place_your_image_here_dou_3.jpg"
            alt=""
            width={339}
            height={301}
          />
          <div className="col-2">
            <p className="title-4">Lorem ipsum</p>
            <p className="body-text-4">
              Lorem ipsum dolor sit amet,
              <br />
              consectetur &nbsp;adipisicing...
            </p>
          </div>
        </div>
        <div className="button-3">
          <a href=""> Show More</a>
        </div>
      </div>
      <div className="content-3">
        <div className="col-3">
          <p className="title-5">Lorem ipsum</p>
          <p className="body-text-5">
            Lorem ipsum dolor sit amet,
            <br />
            consectetur &nbsp;adipisicing...
          </p>
        </div>
      </div>
    </div>
  </div>
  <div className="group-3" id="s">
    <img
      className="place-your-image-here-double-click-to-edit-2"
      src="images/place_your_image_here_dou_2.png"
      alt=""
    />
    <div className="background2">
      <div className="l-constrained-4">
        <div className="text-2">
          <p className="title-6">
            Discount up to
            <br />
            50% All Excursions
          </p>
          <p className="body-text-6">
            Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
            nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat
            volutpat.
          </p>
        </div>
        <div className="button-5">
          <a href="#">Read More</a>
        </div>
      </div>
    </div>
  </div>
        </>
    )
}
export default Second