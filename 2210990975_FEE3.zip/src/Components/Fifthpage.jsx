import React from "react";

const Fifth =() =>{
    return(
        <>
<div className="group7">
    <div className="text-5">
      <div className="row-lorem">
        <div className="column-1">
          <p className="title-10">lorem ipsum</p>
          <p className="body-text-9">
            Lorem ipsum dolor sit amet, consecte
            <br />
            sectetur adipisicing elit, tation omne
            <br />
            ullamco laboris nisi ut aliqolore.
          </p>
        </div>
        <div className="column-2">
          <p className="title-11">Lorem Ipsum</p>
          <p className="body-text-10">
            Lorem ipsum dolor sit amet, consecte
            <br />
            sectetur adipisicing elit, tation omne
            <br />
            ullamco laboris nisi ut aliqolore.
          </p>
        </div>
        <div className="column-3">
          <p className="title-12">Lorem Ipsum</p>
          <p className="body-text-11">
            Lorem ipsum dolor sit amet, consecte
            <br />
            sectetur adipisicing elit, tation omne
            <br />
            ullamco laboris nisi ut aliqolore.
          </p>
        </div>
      </div>
      <p className="text-6">“</p>
      <p className="body-text-12">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis
      </p>
      <p className="name">Lorem Ipsum</p>
    </div>
    <img
      className="shadow-3"
      src="images/shadow.png"
      alt=""
      width={540}
      height={542}
    />
  </div>
  <img className="shape-4" src="images/shape_3.png" alt="" />
        </>
    )
}
export default Fifth