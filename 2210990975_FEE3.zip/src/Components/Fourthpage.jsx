import React from "react";

const Fourth =() =>{
    return(
        <>
<div className="design-2">
    <div className="rectangle-2" />
    <img
      className="shadow-2"
      src="images/shadow_2.png"
      alt=""
      width={529}
      height={408}
    />
    <img className="shape-2" src="images/shape_8.png" alt="" />
    <img className="shape-3" src="images/shape_9.png" alt="" />
    <div className="text-4">
      <p className="title-8">Hiking in the mountains</p>
      <p className="body-text-8">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam quis
      </p>
    </div>
  </div>
  <div className="group-6">
    <div className="image">
      <div className="l-constrained-3">
        <span className="text-style">EXPLORE</span>
        <br />
        THE WORLD
      </div>
    </div>
    <div className="design-3" />
  </div>
        </>
    )
}
export default Fourth