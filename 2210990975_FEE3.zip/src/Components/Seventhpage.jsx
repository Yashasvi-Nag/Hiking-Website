import React from "react";

const Seventh =()=>{
    return(
        <>
<div className="background-3" id="c">
    <div className="footer group">
      <div className="col-1">
        <p className="title-14">Title Here</p>
        <p className="body-text-14">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at
          dignissim nunc, id maximus ex. Etiam nec dignissim elit, at dignissim
          enim.
        </p>
        <div className="social-media">
          <div className="icon group">
            <a href="">
              <img src="images/instagram.png" alt="" width={42} height={42} />
            </a>
            <a href="">
              <img src="images/facebook.png" alt="" width={42} height={42} />
            </a>
            <a href="">
              <img src="images/twitter.png" alt="" width={42} height={42} />
            </a>
            <a href="">
              <img src="images/whatsapp.png" alt="" width={42} height={42} />
            </a>
          </div>
        </div>
      </div>
      <div className="footer2">
        <div className="col-4">
          <p className="title-17">Other</p>
          <p className="body-text-17">
            <a href="">Contact Us</a>
            <br />
            <a href="">Help</a>
            <br />
            <a href="">Privacy</a>
          </p>
        </div>
        <div className="col-3-2">
          <p className="title-16">Services</p>
          <p className="body-text-16">
            <a href="">How to Order</a>
            <br />
            <a href="">Our Product</a>
            <br />
            <a href="">Order Status</a>
            <br />
            <a href="">Promo</a>
            <br />
            <a href="">Payment Method</a>
          </p>
        </div>
        <div className="col-2-2">
          <p className="title-15">About</p>
          <p className="body-text-15">
            <a href="">History</a>
            <br />
            <a href="">Our Team</a>
            <br />
            <a href="">Brand Guidelines</a>
            <br />
            <a href="">Terms &amp; Condition</a>
            <br />
            <a href="">Privacy Policy</a>
          </p>
        </div>
      </div>
    </div>
  </div>
        </>
    )
}
export default Seventh