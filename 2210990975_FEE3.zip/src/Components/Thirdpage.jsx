import React from "react";

const Third =() =>{
    return(
        <>
<div className="backgorund-2">
    <div className="l-constrained-2 group">
      <img
        className="place-your-image-here-double-click-to-edit-3"
        src="images/place_your_image_here_dou.jpg"
        alt=""
      />
      <div className="col-6">
        <div className="text-3">
          <p className="title-7">
            January’s Promo:
            <br />
            Buy 1 Get 1 Free!
          </p>
          <p className="body-text-6">
            Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam
            nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat
            volutpat.
          </p>
        </div>
        <div className="button-100">
          <a href="">Read More</a>
        </div>
      </div>
    </div>
  </div>
        </>
    )
}
export default Third