import React from "react";

const Sixth =() =>{
    return(
        <>
<div className="background-2">
    <div className="l-constrained">
      <div className="text-7">
        <p className="title-13">Title Here</p>
        <p className="body-text-13">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus
          lacinia odio vitae vestibulum vestibulum.
        </p>
      </div>
      <div className="wrapper-3">
        <div className="shape-holder">
          <input className="text-8" placeholder="Your Email" />
        </div>
        <div className="button-9">
          <a href="">Subscribe</a>
        </div>
      </div>
    </div>
  </div>
  <img className="shape-5" src="images/shape_4.png" alt="" />
        </>
    )
}
export default Sixth