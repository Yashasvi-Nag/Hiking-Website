import React, { useState } from 'react';

const First =()=>{
    
    const [menuVisible, setMenuVisible] = useState(false);
    const toggleMenu = () => {
        setMenuVisible(!menuVisible);
      };
    return(
        <>

  <div className="group-1">
    <div className="design">
      <div className="row-2">
        <div className="l-constrained-6 group">
          <nav>
            <img
              className="place-your-logo-here-double-click-to-edit"
              src="images/place_your_logo_here_doub.jpg"
              alt=""
              width={91}
              height={94}
            />
            <button className="menu-btn" onClick={toggleMenu}>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                {/*!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.*/}
                <path d="M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z" />
              </svg>
            </button>
            <ul className={menuVisible ? 'show' : ''}>
              <li>
                <a href="#">Home</a>
              </li>
              <li>
                <a href="#a">About Us</a>
              </li>
              <li>
                <a href="#s">Services</a>
              </li>
              <li>
                <a href="#c">Contact</a>
              </li>
            </ul>
            <div className="wrapper-6">
              <div className="rectangle">
                <input className="rectangle2" type="text" />
              </div>
              <a href="">
                <img
                  className="search"
                  src="images/search.png"
                  alt=""
                  width={30}
                  height={30}
                />
              </a>
            </div>
          </nav>
        </div>
      </div>
      <div className="l-unconstrained">
        <div className="l-constrained-5">
          <p className="title">
            IT´S TIME
            <br />
            FOR HIKING
          </p>
          <p className="subtitle">LOREMIPSUM DOLOR</p>
          <div className="button">
            <a href=""> READ MORE</a>
          </div>
          <p className="body-text">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            iusmod tempor incididunt ut labore et dolore magna.
          </p>
        </div>
      </div>
      <div className="shape" />
    </div>
  </div>

        </>
    )
}
export default First